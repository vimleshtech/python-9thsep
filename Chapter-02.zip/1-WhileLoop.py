i =1 #init
while i<10: #condition
    print(i) #print and new line
    i =i+1 #incrementer


#print in same line
i =1
while i<10:
    print(i,end='') #end is keyword which replace \n with given char
    i=i+1

#print in reverse
i =10
while i>0:
    print(i)
    i=i-1

#print table of given number
t = int(input('enter num :'))
i =1
while i<11:
    #print(i*t)
    print('{} * {} = {}'.format(t,i,t*i)) #{} expression
    i=i+1
    

#wap to get sum of all even and odd numbers between two given range
se =0
so =0
i = int(input('enter first num :'))
e = int(input('enter second num :'))

while i<=e:
    if i%2==0: #is number even 
        se+=i
    else:
        so+=i
    i=i+1
    
print('sum of all even number :',se)
print('sum of all odd number :',so)



        


    





    


    
    
