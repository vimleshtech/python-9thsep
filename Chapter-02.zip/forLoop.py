#for loop
#range(10) 0 1 2 3 ... 9<10

for x in range(10): #0 to 9 #default incrementer is 1
    print(x) 

#print in reverse, 10 9 ... >0
for x in range(10,0,-1):
    print(x)
    
#print
#range(init,condition,increment/decrement)
#init is optional #default is 0
#increment/decrement is optional : default is +1
for i in range(1,11,2): # 1 3 5 7 9
    print(i)
    




