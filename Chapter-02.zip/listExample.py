a =[11,22,34,44,2,2,4]
print(a)

'''
int a[] = {11122,33,44,5}
for (int x : a){
    ..
}
'''
for x in a: 
    print(x)
    


##dynamic list
d = [] #declare empty list 
for i in range(10):
    x = int(input('enter data :'))
    d.append(x)

print(d)

    
