a = input('enter number :') #default input is str
b = input('enter number :')

print(type(a))
print(type(b))

#type casting
a = int(a)
b = int(b)

print(type(a))
print(type(b))

c =a+b
print(c)

