a = int(input('enter number :'))
b = int(input('enter number :'))

print(type(a))
print(type(b))

c =a+b
print(c)

