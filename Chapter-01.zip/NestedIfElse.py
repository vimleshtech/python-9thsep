a = int(input('enter num :'))
b = int(input('enter num :'))
c = int(input('enter num :'))

#show greater number from three inputs
if a>b and a>c:
    print('a is greater')
elif b>a and b>c:
    print('b is greater')
else:
    print('c is greater')



