#CRUD
import mysql.connector as con
c = con.connect(host='localhost',user='root',password='root',database='pyexample')
#create object of cursor class
cur = c.cursor()

def create(uid,name,email):
    cur.execute("insert into users(uid,name,email) values({},'{}','{}')".format(uid,name,email))
    c.commit() #save data 
    

def show():
    cur.execute('select * from users')
    data = cur.fetchall()
    for r in data:
        print(r)


def update(uid,name,email):
    cur.execute("update users set name='{}' , email='{}' where uid={}".format(name,email,uid))
    
    c.commit() #save data 

def delete(uid):
    cur.execute('delete from users where uid={}'.format(uid))
    c.commit()


while True:
    ch = input('press 1 for add 2 for show 3 for update 4 for delete and 0 for exit')
    if ch =='1':
        uid = input('enter uid ')
        name = input('enter name ')
        email = input('enter email')
        
        create(uid,name,email)
    elif ch=='2':
        show()
    elif ch=='3':
        uid = input('enter uid which you want to update ')
        name = input('enter name ')
        email = input('enter email')
        update(uid,name,email)

    elif  ch=='4':
        uid = input('enter uid which want to delete ')
        
        delete(uid)

    elif ch =='0':
        break
    else:
        print('invalid choice, retry !!!')
        

        

        
        


        
    
    

    
