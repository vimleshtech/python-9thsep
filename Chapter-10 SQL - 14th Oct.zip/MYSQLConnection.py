import mysql.connector as con

c = con.connect(host='localhost',user='root',password='root',database='pyexample')

#create object of cursor class
cur = c.cursor()

cur.execute('select * from users')

data = cur.fetchall()

print(data)



