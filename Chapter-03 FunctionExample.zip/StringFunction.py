st = input('enter string :')

print(st.upper())
print(st.lower())
print(st.title())
print(st.capitalize())

print(st.count('a')) #return count of a 
print(len(st)) #count of char inculding space
print(st.replace('a','xy'))  #find and replace

print(st.strip()) #trim leading space 

a = list(st) #break char by char
print(a)

x = st.split() #break by space, default seperator is " "
print(x)

x = st.split('-') #break by -
print(x)


print(st[0:4])
print(st[::-1])#print in reverse


if st.isdigit():
    print('numeric data ')
else:
    print('alpha numeric')
    

if st.endswith('sinha'):
    print('surname is sinha')
else:
    print('surname not match')

fn  = input('enter first name:')
ln  = input('enter last name:')

fullname = fn+' '+ln
print(fullname)

    



    
        





