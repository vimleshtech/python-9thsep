def wel():
    print('function example ...')

def get_input():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b #function can return multiple values from function

def add(a,b):
    print(a+b)

def sub(a,b):
    c =a-b
    return c

#
def add_num(a,b,c=0,d=0,e=0):
    print(a+b+c+d+e)

#dynamic argument
def mul(*n): #* : recieve all arguments in tuple format
    o =1;
    for x in n:
        o*=x
    print(o)

#recussision
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1)

#lambda
f = lambda x: x*.18 #18% tax


#call function
wel()
wel()

x,y= get_input()
print(x+y)
add(x,y)

o = sub(x,y)
print(o)

add_num(11,22,44)
add_num(11,22,44,55,44)

mul(11,3233,44,5)
mul(11,3233,44,5,5,3)

o = fact(6)
print(o)

d = f(100)
print(d)



