import  time
import os

import random
#import re

import shutil  as s #import and crate alias of module
#import selected functions
from math import pi,sqrt,pow

#
from re import *

t = time.localtime()
print(t)

print(t.tm_year)
print(t.tm_mon)

#math
print(pi)
print(sqrt(9))

#random
print(random.randint(1,10))
print(random.randint(1,10))
print(random.randint(1,10))
print(random.randint(1,10))

print(random.randint(1000,9999))


#os
print(os.curdir)
os.chdir(r'C:\Users\vkumar15\Desktop\Content')

print(os.listdir())#list of all files and folder






