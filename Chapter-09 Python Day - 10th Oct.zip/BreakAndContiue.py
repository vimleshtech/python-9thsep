#break 
for x in range(1,10):
    if x%3 ==0:
        break #stop the loop
    print(x)

#continue
for x in range(1,10):
    if x%3 ==0:
        continue #skip the loop
    print(x)
