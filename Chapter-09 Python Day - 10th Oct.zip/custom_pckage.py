class compute:

    def add(s,a,b):
        c = a+b
        print('sum of numbers :',c)

    def mul(s,n1,n2):
        n =n1*n2
        return n
    
