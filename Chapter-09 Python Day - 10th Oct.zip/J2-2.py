class employee:
    def newemp(s):
        s.eid = int(input('enter eid:'))
        s.ename = input('enter name:')
        s.sal = int(input('enter sal:'))
    def compute(s):
        s.msal = s.sal*.40  + s.sal*.20 + s.sal
        s.ysal = s.msal*12
    def show(s):
        print('eid {} name {} msal {} and ysal {}'.format(s.eid,s.ename,s.msal,s.ysal))
#create empty list
items =[]
for i in range(5):
    e = employee()
    e.newemp()
    e.compute()
    items.append(e) #add the reference of object in list 

print(items)
for x in items: #iterate the list 
    x.show()
    
    






    



        
    
