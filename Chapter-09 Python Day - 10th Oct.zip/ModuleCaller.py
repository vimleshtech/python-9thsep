from  custom_pckage import compute

o = compute()
o.add(11,3)
r = o.mul(11,3)
print(r)






