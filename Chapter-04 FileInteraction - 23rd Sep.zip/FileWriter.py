#create new .txt from code

o = open(r'C:\Users\vkumar15\Desktop\Content\newfile.txt','a') #a is mode of file
o.write('hi, this is test file\n')#content \n -new line
o.write('test data 11')
o.close()

print('save file ')

#write user input in file
o = open(r'C:\Users\vkumar15\Desktop\Content\newfile.txt','a') #w is mode of file
for x in range(5):
    s = input('enter data :')
    o.write(s+'\n')

o.close() #save the file
print('save is saved')


