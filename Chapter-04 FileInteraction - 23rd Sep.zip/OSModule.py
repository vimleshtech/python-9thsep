import os

os.chdir(r'C:\Users\vkumar15\Desktop\Content')
print(os.getcwd())

#get list of files and folder from current directory
d = os.listdir()
print(d)

#find and read all .txt file
for f in d:
    #print(f)
    if f.endswith('.txt'):
        #print(f)
        rf = open(f)
        print(rf.read())
        


    

         
