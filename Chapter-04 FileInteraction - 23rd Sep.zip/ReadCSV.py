import pandas as pd

data = pd.read_csv(r'C:\Users\vkumar15\Documents\TestFolder\export.csv')
print(data)


#read excel file
e = pd.read_excel(r'C:\Users\vkumar15\Desktop\Content\Compute.xlsx',sheet_name='Sheet1')

print(e)

