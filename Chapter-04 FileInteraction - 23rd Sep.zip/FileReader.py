#read file
f = open(r'C:\Users\vkumar15\Desktop\Content\newfile.txt') #r mode ,default is r

#print(f.read())
#print(f.readline())#read first line
data = f.readlines() #read all lines and convert to list
print(data)

#get row count
print(len(data))

#wap to get word count
wc = 0
#iterate every row
for r in data:
    #print(r)
    w = r.split()
    wc+= len(w)

print('word count ',wc)

    




