
while True:
    try:
        n = int(input('enter data :'))
        d = int(input('enter data :'))
        o = n/d
        print(o)
        break
    except:
        print('invalid input try again !!!')
    
    
    
