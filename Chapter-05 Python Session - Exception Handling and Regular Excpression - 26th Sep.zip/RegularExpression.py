import re

s = input('enter string :')
o = re.match('(.*) are (.*)',s) #check string contains are or not

if o:
    print('are is present')
else:
    print('are is not present')


#email id validation
email = input('enter email id:')


o = re.search('@gmail.com$',email) #should end with @gamil.com
if o:
    print('valid gmail account')
else:
    print('invalid gmail account ')
    
          
