n = int(input('enter data :'))
d = int(input('enter data :'))

#division
try:

    if d<0:
        msg = ValueError('Divisor cannot be less than 0')
        raise msg  #go to except block
    
    o = n/d
    print(o)
except ValueError as er:
    print(er)

except ZeroDivisionError as e:
    print(e)
    
except:
    pass
    #print('invalid input , try with different data ')
finally:
    print('end of division block ')
    
#addition 
a = n+d
print(a)




