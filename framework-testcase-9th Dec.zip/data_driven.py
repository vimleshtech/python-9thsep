import pandas as pd  # pandas is module 

def get_data():
    data  = pd.read_excel('c:\\data\\test.xlsx',sheet='Sheet1')
    return data 

def get_test_data(test):
    data = get_data()
    test_data = data.values  #convert to array/list 
    selected_data = []
    for row in test_data:
        if row[0] == test:
            selected_data = row 
    
    return selected_data



    




