import selenium.webdriver 
from  data_driven import *
import time 

def init():
    global driver 
    driver = Chrome()

def open():
    driver.get('https://www.yahoo.com')

    
def login():
    user = driver.get_element_by_id('email')
    pwd = driver.get_element_by_id('pwd')
    btn = driver.get_element_by_id('login')

    data = get_test_data("login")


    user.sends_keys(data[1])
    pwd.sends_keys(data[2])
    btn.click()

def imdb():
    driver.get("https://www.imdb.com/")
    time.sleep(4)
    els = dirver.find_elements_by_class_name('trending-list-rank-item-name')
    f = open('out.txt','w')
    for e in  els:
        data = e.get_text()
        f.write(data+'\n')

    f.close()
    

    
if __name__ =='main':
    init()
    open()
    login()
    






