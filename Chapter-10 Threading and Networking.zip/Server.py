import socket               # Import socket module
s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name

print(host)

port = 4050                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

s.listen(16)                 # Now wait for client connection.

while True:
    c,addr = s.accept() #recv data and address of client
    print('got connection from ',addr)
    c.send('Response from server to client '.encode()) #encode() encryp the data
    c.close() 
    
    
