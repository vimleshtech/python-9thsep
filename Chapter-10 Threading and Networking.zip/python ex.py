s=open(r'C:\Users\vkumar15\Desktop\data.txt','a')


for i in range(5):
    b=input('enter the data')
    s.write(b+'\n')

s.close()
print('data is saved')


##
import re

r = open(r'C:\Users\vkumar15\Desktop\data.txt')
d = r.readlines()

for row in d:
    m = re.match('(.*) python (.*)',row)
    if m:
        print(row)

r.close()


    




       



