import time
import threading

def process1():
    for i in range(1,5):
        print(i)
        time.sleep(2) #3 sec is waiting time
    

def process2():
    for j in range(11,15):
        print(j)
        time.sleep(1)


#process1()
#process2()

#create thread instance
p1 = threading.Thread(target=process1,name='thread-1')
p2 = threading.Thread(target=process2,name='thread-2')

p1.start()
p2.start()




    
