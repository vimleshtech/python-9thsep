import threading
import random
import time


def OTP():
    while True:
        o = random.randint(1000,9999)
        print('one time pwd which will valid for next 5 secs',o)
        time.sleep(5)


OTP()
