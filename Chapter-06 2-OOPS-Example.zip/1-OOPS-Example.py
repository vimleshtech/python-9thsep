class Employee:

    def newEmployee(s): #every function will take at least one argument  which is reference of o bject
        print('in new emp fun')
        #print(s,' is created')
        s.eid = int(input('enter data :'))
        s.ename = input('enter name :')
        

    def showEmployee(self):
        print('in show emp fun')
        print('eid is {} and name is {} '.format(self.eid,self.ename))
        


#create object
o = Employee() 
print(o) #print address of object 
o.newEmployee() #error 
o.showEmployee()

    
