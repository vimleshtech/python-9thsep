#constructor and deconstructor
class calc:

    def __init__(s):
        print(s,' object is created')

    def __del__(a):
        print(a,' object is deleted')

    def add(s,a,b):
        c =a+b
        print(c)
    def mul(s,a,b):
            c =a*b
            print(c)

#create object
c = calc()
c.add(1123,4)
c.mul(11,33)
del c #object will remove, so we cannot use further

c.add(11,3) #error

